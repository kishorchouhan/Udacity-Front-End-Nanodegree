# JavaScript Testing

Practice testing your javascript applications using Jasmine!

`git clone https://github.com/udacity/ud549` and open the files in your editor to follow along with [Udacity's JavaScript Testing course](https://www.udacity.com/course/javascript-testing--ud549).
